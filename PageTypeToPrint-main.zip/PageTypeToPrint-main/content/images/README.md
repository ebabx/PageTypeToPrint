## Images

Ce dossier peut servir à stocker les images de votre document.

Dans un fichier texte au format markdown situé dans le dossier `text`, on pourra alors saisir :

```md
(figure: images/url_de_limage.jpg caption: La légende de l’image)
```