<!-- Styles communs -->
<link rel="stylesheet" href="<?= $theme_url ?>/css/style.css">

<!-- Scripts communs  -->
<script src="<?= $theme_url ?>/js/screen/script.js" media="screen"></script>

